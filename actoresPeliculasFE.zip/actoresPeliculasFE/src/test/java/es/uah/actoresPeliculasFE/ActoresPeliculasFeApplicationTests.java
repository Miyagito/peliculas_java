package es.uah.actoresPeliculasFE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActoresPeliculasFeApplicationTests {

	@Test
	void contextLoads() {
	}

}
