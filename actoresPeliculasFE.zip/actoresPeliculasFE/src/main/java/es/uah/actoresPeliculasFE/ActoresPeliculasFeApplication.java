package es.uah.actoresPeliculasFE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActoresPeliculasFeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActoresPeliculasFeApplication.class, args);
	}

}
