package es.uah.actoresPeliculas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActoresPeliculasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActoresPeliculasApplication.class, args);
	}

}
